-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafytrip
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sigugun`
--

DROP TABLE IF EXISTS `sigugun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sigugun` (
  `sido_code` int NOT NULL,
  `gugun_code` int DEFAULT NULL,
  `sigu_name` varchar(30) DEFAULT NULL,
  KEY `sido_code` (`sido_code`),
  KEY `gugun_code` (`gugun_code`),
  CONSTRAINT `sigugun_ibfk_1` FOREIGN KEY (`sido_code`) REFERENCES `sido` (`sido_code`),
  CONSTRAINT `sigugun_ibfk_2` FOREIGN KEY (`gugun_code`) REFERENCES `gugun` (`gugun_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sigugun`
--

LOCK TABLES `sigugun` WRITE;
/*!40000 ALTER TABLE `sigugun` DISABLE KEYS */;
INSERT INTO `sigugun` VALUES (1,NULL,'서울'),(2,NULL,'인천'),(3,NULL,'대전'),(4,NULL,'대구'),(5,NULL,'광주'),(6,NULL,'부산'),(7,NULL,'울산'),(8,NULL,'세종특별자치시'),(31,1,'가평'),(31,2,'고양'),(31,3,'과천'),(31,4,'광명'),(31,5,'광주'),(31,6,'구리'),(31,7,'군포'),(31,8,'김포'),(31,9,'남양주'),(31,10,'동두천'),(31,11,'부천'),(31,12,'성남'),(31,13,'수원'),(31,14,'시흥'),(31,15,'안산'),(31,16,'안성'),(31,17,'안양'),(31,18,'양주'),(31,19,'양평'),(31,20,'여주'),(31,21,'연천'),(31,22,'오산'),(31,23,'용인'),(31,24,'의왕'),(31,25,'의정부'),(31,26,'이천'),(31,27,'파주'),(31,28,'평택'),(31,29,'포천'),(31,30,'하남'),(31,31,'화성'),(32,1,'강릉'),(32,2,'고성'),(32,3,'동해'),(32,4,'삼척'),(32,5,'속초'),(32,6,'양구'),(32,7,'양양'),(32,8,'영월'),(32,9,'원주'),(32,10,'인제'),(32,11,'정선'),(32,12,'철원'),(32,13,'춘천'),(32,14,'태백'),(32,15,'평창'),(32,16,'홍천'),(32,17,'화천'),(32,18,'횡성'),(33,1,'괴산'),(33,2,'단양'),(33,3,'보은'),(33,4,'영동'),(33,5,'옥천'),(33,6,'음성'),(33,7,'제천'),(33,8,'진천'),(33,9,'청원'),(33,10,'청주'),(33,11,'충주'),(33,12,'증평'),(34,1,'공주'),(34,2,'금산'),(34,3,'논산'),(34,4,'당진'),(34,5,'보령'),(34,6,'부여'),(34,7,'서산'),(34,8,'서천'),(34,9,'아산'),(34,11,'예산'),(34,12,'천안'),(34,13,'청양'),(34,14,'태안'),(34,15,'홍성'),(34,16,'계룡'),(35,1,'경산'),(35,2,'경주'),(35,3,'고령'),(35,4,'구미'),(35,5,'군위'),(35,6,'김천'),(35,7,'문경'),(35,8,'봉화'),(35,9,'상주'),(35,10,'성주'),(35,11,'안동'),(35,12,'영덕'),(35,13,'영양'),(35,14,'영주'),(35,15,'영천'),(35,16,'예천'),(35,17,'울릉'),(35,18,'울진'),(35,19,'의성'),(35,20,'청도'),(35,21,'청송'),(35,22,'칠곡'),(35,23,'포항'),(36,1,'거제'),(36,2,'거창'),(36,3,'고성'),(36,4,'김해'),(36,5,'남해'),(36,6,'마산'),(36,7,'밀양'),(36,8,'사천'),(36,9,'산청'),(36,10,'양산'),(36,12,'의령'),(36,13,'진주'),(36,14,'진해'),(36,15,'창녕'),(36,16,'창원'),(36,17,'통영'),(36,18,'하동'),(36,19,'함안'),(36,20,'함양'),(36,21,'합천'),(37,1,'고창'),(37,2,'군산'),(37,3,'김제'),(37,4,'남원'),(37,5,'무주'),(37,6,'부안'),(37,7,'순창'),(37,8,'완주'),(37,9,'익산'),(37,10,'임실'),(37,11,'장수'),(37,12,'전주'),(37,13,'정읍'),(37,14,'진안'),(38,1,'강진'),(38,2,'고흥'),(38,3,'곡성'),(38,4,'광양'),(38,5,'구례'),(38,6,'나주'),(38,7,'담양'),(38,8,'목포'),(38,9,'무안'),(38,10,'보성'),(38,11,'순천'),(38,12,'신안'),(38,13,'여수'),(38,16,'영광'),(38,17,'영암'),(38,18,'완도'),(38,19,'장성'),(38,20,'장흥'),(38,21,'진도'),(38,22,'함평'),(38,23,'해남'),(38,24,'화순'),(39,NULL,'제주도');
/*!40000 ALTER TABLE `sigugun` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-23 14:30:15
